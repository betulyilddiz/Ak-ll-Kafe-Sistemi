﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafe2
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }

    // User class with encapsulated properties
    public class User : Entity
    {
        public string Name { get; private set; }
        public string Email { get; private set; }
        public string PhoneNumber { get; private set; }
        public string Password { get; set; }
        public bool HasParticipatedInDraw { get;  set; }
        public bool InDraw { get;  set; }

        public User(string name, string email, string phoneNumber, string password)
        {
            Name = name;
            Email = email;
            PhoneNumber = phoneNumber;
            Password = password;
            HasParticipatedInDraw = false;
            InDraw = false;
        }

        public bool ValidatePassword(string password) => Password == password;
        public void JoinDraw() => InDraw = true;
        public void MarkDrawParticipation() => HasParticipatedInDraw = true;
    }
}
