﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafe2
{
    public class Order : Entity
    {
        public User User { get; private set; }
        public List<OrderItem> Items { get; private set; }
        public double TotalPrice => Items.Sum(item => item.Product.Price * item.Quantity);

        public Order(User user, List<OrderItem> items)
        {
            User = user;
            Items = items;
        }
    }

    public class OrderItem
    {
        public Product Product { get; private set; }
        public int Quantity { get; set; }

        public OrderItem(Product product, int quantity)
        {
            Product = product;
            Quantity = quantity;
        }
    }
}
